export default{
    BUTTON_COLOR: '#1abc8c',
    BACKGROUND_COLOR: '#1abc9c'
}