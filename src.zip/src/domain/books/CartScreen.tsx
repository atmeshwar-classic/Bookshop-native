import { View,Text,Button } from "react-native";
import * as React from 'react';


export const CartScreen = ({navigation}: any) => {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Cart!</Text>
      
    </View>
  );
  }




