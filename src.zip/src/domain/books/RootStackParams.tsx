
export type RootStackParamList = {
    Books: {name: string},
    Cart: {name: string}; 
};