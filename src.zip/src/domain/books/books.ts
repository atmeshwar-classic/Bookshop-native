import { Book } from "./types";

export const books: Book[] = [
  {
    id: '123',
    name: 'Book',
    author: 'Author',
    description: 'Description',
    price: 20
  },
  {
    id: '124',
    name: 'Book',
    author: 'Author',
    description: 'Description',
    price: 20
  },
  {
    id: '125',
    name: 'Book',
    author: 'Author',
    description: 'Description',
    price: 20
  },
]